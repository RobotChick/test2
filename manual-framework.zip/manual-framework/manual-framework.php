<?php 
/* 
 * Plugin Name:   Manual Framework (Post Type) 
 * Version:       4.3
 * Plugin URI:    https://smartwpthemes.com/
 * Description:   <strong>Support MANUAL wordpress theme</strong>.
 * Author:        pixelacehq (Jabin Kadel)
 * Author URI:    https://smartwpthemes.com/
 *
 * License: Copyright (c) 2022 SmartWpThemes.com. All rights reserved.
 *  
 */

$manual_framework_get_theme = wp_get_theme();
if ( in_array( $manual_framework_get_theme->get( 'Name' ), array( 'Manual', 'Manual Child Theme' ) ) ) {

		define( 'MANUALSUPPORT_PLUGIN', __FILE__ );
		define( 'MANUALSUPPORT_PLUGIN_VERSION', 4.3 );
		define( 'MANUALSUPPORT_PLUGIN_DIR', untrailingslashit( dirname( MANUALSUPPORT_PLUGIN ) ) );
		
		/********************************
		*** ACTIVATE PLUGIN ACTION  ***
		***********************************/
		$manual_framework_path     = preg_replace('/^.*wp-content[\\\\\/]plugins[\\\\\/]/', '', __FILE__);
		$manual_framework_path     = str_replace('\\','/',$manual_framework_path);
		
		// Langauge Support
		add_action('plugins_loaded', 'manual_framework_load_textdomain');
		function manual_framework_load_textdomain() {
				load_plugin_textdomain( 'manual-framework', false, plugin_basename( dirname( __FILE__ ) ) . '/languages/' );
		}
		
		// Version Upgrade
		add_action('activate_'.$manual_framework_path, 'manual_framework_plugin_active'); 
		function manual_framework_plugin_active() {
			update_option( 'manual_theme_framework_version', MANUALSUPPORT_PLUGIN_VERSION );
			return true;
		}
		
		// Styles and JS scripts
		function manual_framework_admin_style_and_scripts() {
			wp_enqueue_style( 'manual-framework-styles', plugin_dir_url( __FILE__ ) . 'assets/css/manual-framework.css' );
			wp_enqueue_script( 'manual-framework-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/manual-framework.js', [], '1.1' );
			wp_enqueue_script( 'manual-framework-license', plugin_dir_url( __FILE__ ) . 'assets/js/manual-active.js', [], '1.1' );
		}
		add_action( 'admin_enqueue_scripts', 'manual_framework_admin_style_and_scripts' );
		
		require MANUALSUPPORT_PLUGIN_DIR . '/manual-post-type.php';
		require MANUALSUPPORT_PLUGIN_DIR . '/widget/widget-social.php';
		require MANUALSUPPORT_PLUGIN_DIR . '/widget/widget-button.php';
		require MANUALSUPPORT_PLUGIN_DIR . '/widget/widget-woo.php';
		if(is_admin()) { 
			require MANUALSUPPORT_PLUGIN_DIR . '/admin/admin.php'; 
			require MANUALSUPPORT_PLUGIN_DIR . '/announcement/main.php'; 
			require MANUALSUPPORT_PLUGIN_DIR . '/inc/function.php';
		}
		
} else {
	add_action( 'admin_notices', 'manual_framework_admin_notice' );
	function manual_framework_admin_notice() {
?>
	<div class="notice notice-error">
		<p>
			<strong><?php esc_html_e( '"Manual Framework" plugin is not supported by this theme', 'manual-framework' ); ?></strong>
			<br>
			<?php esc_html_e( 'Please use this plugin with Manual theme, or deactivate it.', 'manual-framework' ); ?>
		</p>
	</div>
<?php
	}
}
?>