<?php 
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<div class="manual-theme-admin-body-group">
	<div class="manual-theme-admin-body-group-headline">
		<h3>Likes/Dislikes & Impression Global Reset</h3>
	</div>
	<div class="manual-theme-admin-body-group-details">
        <form method="post" action="options.php"  onsubmit="return confirm('<?php _e( 'Are you sure you want to rest all the post stats? Please note this process cannot be reversed.', 'manual-framework' );  ?>');">
			<?php
				settings_fields("manual_plugin__generalsettings_options_reset");
				do_settings_sections("manual-plugin-theme-posttype-options-reset");
				submit_button( __( 'Reset Selected Post Type Stats', 'manual-framework' ), 'secondary', 'manualposttypestatsreset' );
            ?>         
        </form>
	</div>
</div>