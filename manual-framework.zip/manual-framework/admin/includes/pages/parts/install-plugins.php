<?php 
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<style>
.tgmpa.wrap h1, select#bulk-action-selector-top, input#doaction {
	display:none;
}
.tablenav {
	height: 13px;
}
td.type.column-type {
	font-weight: 600;
}
.tgmpa .subsubsub li {
    display: inline-block!important;
}
.tgmpa tr:nth-child(even){background-color: #f2f2f2;}

.tgmpa tr:hover {background-color: #f5f5f5;}

.tgmpa th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  color: white;
}
</style>
<div class="wrap about-wrap">
<?php 
	$tgm_page_plugins = new TGM_Plugin_Activation();
	echo '<div id="manual-theme-install-plugins">';
	$tgm_page_plugins->install_plugins_page();
	echo '</div>';
?>
</div>
