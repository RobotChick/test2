<?php 
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<div class="manual-theme-admin-body-group manual-theme-admin-body-group-success manual-theme-admin-body-group-outline">
  <div class="manual-theme-admin-body-group-headline">
    <h3>Theme Custom Help</h3>
    <a class="btn btn-primary" href="https://smartwpthemes.com/customization/" target="_blank">Request for Quotation</a> </div>
  <div class="manual-theme-admin-body-group-content"> Need some custom work done for your theme? We have an amazing freelance team who can help! <a href="https://smartwpthemes.com/customization/" style="text-decoration:underline;" target="_blank">Request for Quotation</a></div>
</div>
