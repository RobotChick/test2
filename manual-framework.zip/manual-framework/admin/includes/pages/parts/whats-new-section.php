<?php
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<div class="manual-theme-admin-body-group">
	<div class="manual-theme-admin-body-group-headline">
		<h3><?php _e( 'Release Notes', 'manual-framework' ); ?></h3>
        <a class="btn btn-primary" href="https://themeforest.net/item/manual-multipurpose-online-documentation-creative-wordpress-theme/12997044#item-description__changelog" target="_blank"><?php _e( 'View All Changelog', 'manual-framework' ); ?></a> 
	</div>
	<div class="manual-theme-admin-body-group-details server-pull">
        <?php 
		$manual__aAnnouncements = new manual__aAnnouncements();
		$manual__aAnnouncements->manual__dashboard_announcement_screen();
		?>
	</div>
</div>