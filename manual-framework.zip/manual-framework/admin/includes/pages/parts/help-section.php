<?php 
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<!-- Group 1-->
<div class="manual-theme-admin-body-group manual-theme-admin-body-group-outline">
  <div class="manual-theme-admin-body-group-headline">
    <h3>Theme Support</h3>
    <a class="btn btn-primary" href="https://smartwpthemes.com/community-forum/" target="_blank">Help Center</a> </div>
  <div class="manual-theme-admin-body-group-content"> Requests are processed on business days <b>from 10:00 to 17:00 GMT+5:45 within 24hrs</b> in the order they were received. Requests sent during weekends/holidays will be processed on Monday or the next business day. </div>
</div>
<!-- Group 2-->
<div class="manual-theme-admin-body-group manual-theme-admin-body-group-success manual-theme-admin-body-group-outline">
  <div class="manual-theme-admin-body-group-headline">
    <h3>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
        <path d="M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm4.393 7.5l-5.643 5.784-2.644-2.506-1.856 1.858 4.5 4.364 7.5-7.643-1.857-1.857z"/>
      </svg>
      What's included in item support</h3>
  </div>
  <div class="manual-theme-admin-body-group-content">
    <ul>
      <li><i class="dashicons dashicons-yes"></i> Questions about theme usage.</li>
      <li><i class="dashicons dashicons-yes"></i> Theme technical questions.</li>
      <li><i class="dashicons dashicons-yes"></i> Assistance with reported bugs and issues.</li>
    </ul>
  </div>
</div>
<!-- Group 3-->
<div class="manual-theme-admin-body-group manual-theme-admin-body-group-warning manual-theme-admin-body-group-outline">
  <div class="manual-theme-admin-body-group-headline">
    <h3>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
        <path d="M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.094l-4.157-4.104 4.1-4.141-1.849-1.849-4.105 4.159-4.156-4.102-1.833 1.834 4.161 4.12-4.104 4.157 1.834 1.832 4.118-4.159 4.143 4.102 1.848-1.849z"/>
      </svg>
      What's not included in item support</h3>
  </div>
  <div class="manual-theme-admin-body-group-content">
    <ul>
      <li><i class="dashicons dashicons-no"></i> Theme customization.</li>
      <li><i class="dashicons dashicons-no"></i> Installation of the theme.</li>
      <li><i class="dashicons dashicons-no"></i> Hosting, server environment, or software.</li>
      <li><i class="dashicons dashicons-no"></i> Help of included third party assets.</li>
    </ul>
  </div>
</div>
