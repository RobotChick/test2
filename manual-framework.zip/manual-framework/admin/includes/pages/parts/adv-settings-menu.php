<?php 
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://smartwpthemes.com/
 * @package    Manual
 * @since      4.0
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<div class="manual-theme-admin-body-group">
	<div class="manual-theme-admin-body-group-headline">
		<h3>Post Type Display - On/Off</h3>
	</div>
	<div class="manual-theme-admin-body-group-details">
        <form method="post" action="options.php">
			<?php
				settings_fields("manual_plugin__generalsettings_options");
				do_settings_sections("manual-plugin-theme-posttype-options");
				submit_button();
            ?>         
        </form>
	</div>
</div>