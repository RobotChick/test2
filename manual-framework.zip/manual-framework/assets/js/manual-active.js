/*********************
META BOX :: SHOW HIDE  
**********************/
jQuery(document).ready(function() {
								
		"use strict";						
		
		// OnClick action.
         jQuery("#manual_license_status").on("click",function() {
			if ( ! confirm('Are you sure you want to delete the license? Please note this process cannot be reversed')) return; 
				if ( jQuery(this).attr('loading') ) {
					return false;
				}
				
				jQuery(this).attr('loading', true).addClass('btn-spinner').text('Removing..');
				
				jQuery.post(window.ajaxurl, { 'action': 'manual_theme_remove_license_code' }, () => {
					window.location.reload();
				});
		});
			
});			  